// Initialize login functionality
initLogin();
