// Initialize logout functionality
initLogout();
