// Initialize signup functionality
initSignup();
