/**
 * Event Handlers and Listeners
 * Handles user interactions, messaging, and collapsible sections
 */

window.PopupEvents = {
  initialize() {
    this.setupSpeedTestHandlers();
    this.setupSettingsHandlers();
    this.setupLoadTestHandlers();
    this.setupCollapsibleHandlers();
    this.setupMessageListener();
    this.setupPromoBannerHandlers();
    this.setupAdditionalToolsHandlers();
    this.setupModalCloseHandlers();
    this.setupFeedbackHandlers();
    this.checkFeedbackStatus();
  },

  async checkFeedbackStatus() {
    const { elements, state } = window.PopupApp;
    if (!elements.feedbackRatingContainer) return;

    try {
      // Get user info from storage
      const result = await new Promise((resolve) =>
        chrome.storage.local.get(
          ["user_id", "user_email", "user_hash"],
          resolve,
        ),
      );

      const userId = result.user_id || result.user_email || "anonymous";

      if (userId === "anonymous") {
        // If anonymous user, show feedback buttons
        elements.feedbackRatingContainer.style.display = "block";
        return;
      }

      // Check feedback status via API
      const response = await fetch(
        `https://feedback-collector.sumanreddy568.workers.dev/check-feedback?userId=${encodeURIComponent(userId)}`,
        {
          method: "GET",
          mode: "cors",
          cache: "no-cache",
          credentials: "omit",
          headers: {
            Accept: "application/json",
          },
        },
      );

      if (response.ok) {
        const data = await response.json();

        if (data.hasSubmittedFeedback) {
          elements.feedbackRatingContainer.style.display = "none";
        } else {
          elements.feedbackRatingContainer.style.display = "block";
        }
      } else {
        // If API fails, show feedback buttons as fallback
        elements.feedbackRatingContainer.style.display = "block";
      }
    } catch (error) {
      console.warn("Failed to check feedback status:", error);
      // If error, show feedback buttons as fallback
      elements.feedbackRatingContainer.style.display = "block";
    }
  },

  setupFeedbackHandlers() {
    const { elements, state } = window.PopupApp;
    if (!elements.thumbsUp || !elements.thumbsDown || !elements.feedbackModal)
      return;

    // Thumbs up/down handlers (from main page)
    elements.thumbsUp.addEventListener("click", () => {
      this.handleRatingClick(
        "positive",
        "What did you like about your speed test?",
      );
    });

    elements.thumbsDown.addEventListener("click", () => {
      this.handleRatingClick(
        "negative",
        "What issues did you experience with your speed test?",
      );
    });

    // Close modal
    elements.feedbackClose.addEventListener("click", () => {
      elements.feedbackModal.style.display = "none";
    });

    // Outside click closes modal
    window.addEventListener("click", (event) => {
      if (event.target === elements.feedbackModal) {
        elements.feedbackModal.style.display = "none";
      }
    });

    // Submit feedback
    elements.submitFeedback.addEventListener("click", async () => {
      const feedback = elements.feedbackText.value.trim();
      if (!feedback) {
        elements.feedbackStatus.textContent =
          "Please enter a message before submitting.";
        elements.feedbackStatus.style.color = "#dc3545";
        return;
      }

      elements.submitFeedback.disabled = true;
      elements.feedbackStatus.textContent = "Sending...";
      elements.feedbackStatus.style.color = "#666";

      // Collect userId (from storage or fallback)
      let userInfo = {
        userId: "anonymous",
        email: null,
        userHash: null,
      };

      try {
        const result = await new Promise((resolve) =>
          chrome.storage.local.get(
            ["user_id", "user_email", "user_hash"],
            resolve,
          ),
        );
        userInfo = {
          userId: result.user_id || result.user_email || "anonymous",
          email: result.user_email || null,
          userHash: result.user_hash || null,
        };
      } catch (e) {
        console.warn("Failed to fetch user info for feedback:", e);
      }

      // Collect speed and network info (if available)
      const info = state.networkInfoCache || {};
      const payload = {
        source: "speed100-extension",
        userId: userInfo.userId,
        userEmail: userInfo.email,
        userHash: userInfo.userHash,
        feedback,
        rating: state.selectedRating,
        downloadSpeed:
          document.getElementById("download-speed")?.textContent || null,
        uploadSpeed:
          document.getElementById("upload-speed-display")?.textContent || null,
        ping: info.ping || null,
        jitter: info.jitter || null,
        packetLoss: info.packetLoss || null,
        ipAddress: info.ipAddress || null,
        isp: info.isp || null,
        location: info.location || null,
        server: info.serverInfo || null,
        timestamp: new Date().toISOString(),
      };

      try {
        const res = await fetch(
          "https://feedback-collector.sumanreddy568.workers.dev/feedback/",
          {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            credentials: "omit",
            headers: {
              "Content-Type": "application/json",
              Accept: "*/*",
              "Accept-Language": "en-US,en;q=0.9",
              "Accept-Encoding": "gzip, deflate, br, zstd",
            },
            body: JSON.stringify(payload),
          },
        );
        if (res.ok) {
          state.feedbackSubmitted = true;
          // Save feedback state to storage
          chrome.storage.local.set({ feedbackSubmitted: true });
          console.log("Feedback submitted successfully, marking as complete");

          elements.feedbackStatus.textContent = "Thank you for your feedback!";
          elements.feedbackStatus.style.color = "#28a745";

          // Hide feedback rating container
          elements.feedbackRatingContainer.style.display = "none";

          setTimeout(() => {
            elements.feedbackModal.style.display = "none";
          }, 1500);
        } else {
          elements.feedbackStatus.textContent =
            "Failed to send feedback. Please try again.";
          elements.feedbackStatus.style.color = "#dc3545";
        }
      } catch (e) {
        elements.feedbackStatus.textContent =
          "Error sending feedback. Check your connection.";
        elements.feedbackStatus.style.color = "#dc3545";
      }
      elements.submitFeedback.disabled = false;
    });
  },

  handleRatingClick(rating, promptText) {
    const { elements, state } = window.PopupApp;
    state.selectedRating = rating;

    // Set the modal title and prompt
    elements.feedbackPrompt.textContent = promptText;

    // Show the modal
    elements.feedbackModal.style.display = "block";
    elements.feedbackText.focus();
    elements.feedbackStatus.textContent = "";
    elements.feedbackText.value = "";
  },

  setupSpeedTestHandlers() {
    const { elements, state } = window.PopupApp;
    elements.runTestBtn.addEventListener("click", async () => {
      console.log("Speed test button clicked");

      // Check feedback status before allowing test
      const canRunTest = await this.checkCanRunTest();
      console.log("Can run test:", canRunTest);

      if (!canRunTest) {
        console.log("Test blocked - feedback required");
        elements.testStatus.textContent =
          "Please rate your previous experience before running another test.";
        elements.testStatus.style.color = "#dc3545";
        // Show feedback rating if it's hidden
        elements.feedbackRatingContainer.style.display = "block";
        return;
      }

      console.log("Test allowed - starting speed test");
      if (window.Analytics?.trackSpeedTest) window.Analytics.trackSpeedTest();

      elements.testStatus.textContent = "Starting test...";
      elements.testStatus.style.color = "#666";
      elements.runTestBtn.disabled = true;
      elements.runTestBtn.textContent = "Testing...";

      // Initial UI update for testing state
      window.PopupNetwork.updateInfo({
        ...state.networkInfoCache,
        status: "testing",
        ipAddress: "Testing...",
        dns: "Testing...",
        latency: "Testing...",
        isp: "Testing...",
        ping: "...",
        jitter: "...",
        packetLoss: "...",
      });

      chrome.runtime.sendMessage({ type: "runTest" }, (response) => {
        setTimeout(() => {
          elements.runTestBtn.disabled = false;
          elements.runTestBtn.textContent = "Run Speed Test";
          if (response && response.error) {
            window.PopupNetwork.updateInfo(state.networkInfoCache);
          } else {
            console.log("Test completed successfully");
            // Mark that a test has been completed
            chrome.storage.local.set({ hasRunFirstTest: true });

            // After successful test, show feedback rating and require feedback for next test
            state.feedbackSubmitted = false;
            chrome.storage.local.set({ feedbackSubmitted: false });
            console.log("Requiring feedback for next test");

            elements.testStatus.style.color = "#4285f4";
          }
        }, 15000);
      });
    });
  },

  async checkCanRunTest() {
    try {
      // Get user info from storage
      const result = await new Promise((resolve) =>
        chrome.storage.local.get(
          [
            "user_id",
            "user_email",
            "user_hash",
            "hasRunFirstTest",
            "feedbackSubmitted",
          ],
          resolve,
        ),
      );

      const userId = result.user_id || result.user_email || "anonymous";
      const hasRunFirstTest = result.hasRunFirstTest || false;

      console.log("checkCanRunTest:", {
        hasRunFirstTest,
        userId,
        localFeedbackSubmitted: result.feedbackSubmitted,
      });

      // If this is the very first test ever, allow it
      if (!hasRunFirstTest) {
        console.log("Allowing first test");
        return true;
      }

      // If they've run a test before, check if feedback has been submitted
      console.log("Must check feedback before allowing test");

      // For anonymous users, check local storage
      if (userId === "anonymous") {
        const canRun = result.feedbackSubmitted || false;
        console.log("Anonymous user, can run:", canRun);
        return canRun;
      }

      // For registered users, check API
      try {
        const response = await fetch(
          `https://feedback-collector.sumanreddy568.workers.dev/check-feedback?userId=${encodeURIComponent(userId)}`,
          {
            method: "GET",
            mode: "cors",
            cache: "no-cache",
            credentials: "omit",
            headers: {
              Accept: "application/json",
            },
          },
        );

        if (response.ok) {
          const data = await response.json();
          console.log("API response:", data);
          return data.hasSubmittedFeedback || false;
        } else {
          console.warn("API failed, falling back to local state");
          return result.feedbackSubmitted || false;
        }
      } catch (apiError) {
        console.warn("API error, falling back to local state:", apiError);
        return result.feedbackSubmitted || false;
      }
    } catch (error) {
      console.warn("Failed to check if can run test:", error);
      // If everything fails, be safe and block the test
      return false;
    }
  },

  setupSettingsHandlers() {
    const { elements } = window.PopupApp;

    elements.settingsIcon.addEventListener("click", () => {
      elements.settingsModal.style.display = "block";
    });

    elements.saveSettings.addEventListener("click", async () => {
      const interval = elements.testInterval.value;
      const apiKey = elements.openRouterApiKeyInput
        ? elements.openRouterApiKeyInput.value.trim()
        : "";
      const llmModel = elements.llmModelInput
        ? elements.llmModelInput.value.trim()
        : "";

      const storagePromises = [
        chrome.storage.sync.set({ testInterval: interval }),
      ];

      if (elements.openRouterApiKeyInput) {
        if (apiKey)
          storagePromises.push(
            chrome.storage.local.set({ openRouterApiKey: apiKey }),
          );
        else
          storagePromises.push(chrome.storage.local.remove("openRouterApiKey"));
      }

      if (elements.llmModelInput) {
        if (llmModel) {
          storagePromises.push(chrome.storage.local.set({ llmModel }));
          storagePromises.push(chrome.storage.sync.set({ llmModel }));
        } else {
          storagePromises.push(chrome.storage.local.remove("llmModel"));
          storagePromises.push(chrome.storage.sync.remove("llmModel"));
        }
      }

      try {
        await Promise.all(storagePromises);
        chrome.alarms.clear("nextSpeedTest");
        if (interval !== "0") {
          chrome.alarms.create("nextSpeedTest", {
            periodInMinutes: parseInt(interval, 10),
          });
        }
        elements.settingsModal.style.display = "none";
      } catch (error) {
        console.error("Failed to save settings:", error);
      }
    });

    window.addEventListener("click", (event) => {
      if (event.target === elements.settingsModal)
        elements.settingsModal.style.display = "none";
      if (
        event.target === elements.loadTestModal &&
        !window.PopupApp.state.isLoadTestRunning
      ) {
        elements.loadTestModal.style.display = "none";
      }
    });
  },

  setupLoadTestHandlers() {
    const { elements, state } = window.PopupApp;

    elements.runLoadTestBtn.addEventListener("click", () => {
      if (!state.isLoadTestRunning) {
        elements.loadTestModal.style.display = "block";
        elements.startLoadTest.textContent = "Start Load Test";
        elements.progressFill.style.width = "0";
        elements.loadTestStatus.textContent = "";
      }
    });

    elements.startLoadTest.addEventListener("click", async () => {
      if (state.isLoadTestRunning) return;

      if (window.Analytics?.trackLoadTest) window.Analytics.trackLoadTest();

      const fileSizeMB = parseInt(elements.loadSizeSelect.value, 10);
      const speedTest = new window.SpeedTest();

      state.isLoadTestRunning = true;
      elements.startLoadTest.disabled = true;
      elements.startLoadTest.textContent = "Testing...";
      elements.runTestBtn.disabled = true;
      elements.runLoadTestBtn.disabled = true;
      document.body.classList.add("test-running");

      try {
        const result = await speedTest.runLoadTest(fileSizeMB, (progress) => {
          elements.progressFill.style.width = `${progress.progress * 100}%`;
          window.PopupSpeedometer.update("download", progress.speedMbps);
          elements.loadTestStatus.textContent =
            `Speed: ${progress.speedMbps.toFixed(2)} Mbps | ` +
            `${(progress.bytesReceived / 1024 / 1024).toFixed(0)}MB of ${fileSizeMB}MB | ` +
            `Time: ${progress.elapsedSeconds.toFixed(1)}s`;
        });

        if (result.success) {
          const historyEntry = {
            timestamp: Date.now(),
            fileSizeMB,
            averageSpeedMbps: result.averageSpeedMbps,
            totalTime: result.totalTime,
          };
          state.loadTestHistory.unshift(historyEntry);
          state.loadTestHistory = state.loadTestHistory.slice(0, 3);
          chrome.storage.local.set({ loadTestHistory: state.loadTestHistory });
          window.PopupCharts.updateLoadHistory();
          elements.loadTestStatus.textContent =
            `Complete! Average Speed: ${result.averageSpeedMbps.toFixed(2)} Mbps | ` +
            `Total Time: ${result.totalTime.toFixed(1)}s`;
        } else {
          elements.loadTestStatus.textContent = `Error: ${result.error}`;
        }
      } catch (error) {
        elements.loadTestStatus.textContent = `Error: ${error.message}`;
      } finally {
        state.isLoadTestRunning = false;
        elements.startLoadTest.disabled = false;
        elements.startLoadTest.textContent = "Start Load Test";
        elements.runTestBtn.disabled = false;
        elements.runLoadTestBtn.disabled = false;
        document.body.classList.remove("test-running");
        setTimeout(() => window.PopupSpeedometer.update("download", 0), 2000);
      }
    });
  },

  setupCollapsibleHandlers() {
    const sections = [
      {
        id: "speed-history-header",
        elementSelector: ".speed-history-graph",
        storageKey: "speedHistoryCollapsed",
        updateFn: () => window.PopupCharts.updateHistoryGraph(),
      },
      {
        id: "load-history-header",
        elementSelector: ".load-history-graph",
        storageKey: "loadHistoryCollapsed",
        updateFn: () => window.PopupCharts.updateLoadHistory(),
      },
      {
        id: "network-info-header",
        elementSelector: ".network-info",
        storageKey: "networkInfoCollapsed",
      },
      {
        id: "ai-insights-header",
        elementSelector: ".ai-insights",
        storageKey: "aiInsightsCollapsed",
        updateFn: () => window.PopupAI.updateContent(),
      },
      {
        id: "additional-tools-header",
        elementSelector: ".additional-tools",
        storageKey: "additionalToolsCollapsed",
      },
    ];

    sections.forEach((section) => {
      const header = document.getElementById(section.id);
      const contentElement = document.querySelector(section.elementSelector);
      if (header && contentElement) {
        header.addEventListener("click", () => {
          const isNowCollapsed = contentElement.classList.toggle("collapsed");
          if (!isNowCollapsed && section.updateFn) {
            setTimeout(section.updateFn, 300);
          }
          chrome.storage.local.set({ [section.storageKey]: isNowCollapsed });
        });
      }
    });

    // Initialize collapsed states
    chrome.storage.local.get(
      sections.map((s) => s.storageKey),
      (result) => {
        sections.forEach((section) => {
          const contentElement = document.querySelector(
            section.elementSelector,
          );
          if (contentElement && result[section.storageKey]) {
            contentElement.classList.add("collapsed");
          }
        });
      },
    );
  },

  setupMessageListener() {
    const { state, elements } = window.PopupApp;
    chrome.runtime.onMessage.addListener((request) => {
      if (request.type === "speedUpdate") {
        if (request.error) {
          elements.testStatus.textContent = request.error;
          window.PopupSpeedometer.update("download", 0);
          window.PopupSpeedometer.update("upload", 0);
          window.PopupNetwork.updateInfo({
            ...state.networkInfoCache,
            status: "error",
            error: request.error,
          });
        } else {
          const downloadSpeedMbps = (request.downloadSpeed || 0) / 1000000;
          const uploadSpeedMbps = (request.uploadSpeed || 0) / 1000000;
          window.PopupSpeedometer.animate("download", downloadSpeedMbps);
          window.PopupSpeedometer.animate("upload", uploadSpeedMbps);
          window.PopupNetwork.updateInfo(
            request.networkInfo || state.networkInfoCache,
          );
          elements.testStatus.textContent =
            "Last test: " + new Date().toLocaleTimeString();

          const historyItem = {
            downloadSpeed: request.downloadSpeed,
            uploadSpeed: request.uploadSpeed,
            timestamp: Date.now(),
          };
          state.speedTestHistory.unshift(historyItem);
          state.speedTestHistory = state.speedTestHistory.slice(0, 3);
          window.PopupCharts.updateHistoryGraph();
          chrome.storage.local.set({
            speedTestHistory: state.speedTestHistory,
          });
        }
      } else if (request.type === "testProgress") {
        const downloadMbps = (request.downloadSpeed || 0) / 1000000;
        const uploadMbps = (request.uploadSpeed || 0) / 1000000;
        window.PopupSpeedometer.update("download", downloadMbps);
        window.PopupSpeedometer.update("upload", uploadMbps);
        if (request.networkInfo)
          window.PopupNetwork.updateInfo(request.networkInfo);
        elements.testStatus.textContent = request.message || "Testing...";
      }

      if (request.aiAnalysis) window.PopupAI.updateInsights(request.aiAnalysis);
    });
  },

  setupPromoBannerHandlers() {
    const rateUsLink = document.querySelector(".promo-link.rate");
    const aiAgentsLink = document.querySelector(".promo-link.ai");
    const promoBanner = document.getElementById("promotional-banner");
    const promoClose = document.getElementById("promo-close");

    const updateStatus = () => {
      const rateUsClicked =
        localStorage.getItem("promoRateUsClicked") === "true";
      const aiAgentsClicked =
        localStorage.getItem("promoAiAgentsClicked") === "true";
      if (rateUsClicked && rateUsLink) rateUsLink.classList.add("clicked");
      if (aiAgentsClicked && aiAgentsLink)
        aiAgentsLink.classList.add("clicked");

      if (rateUsClicked && aiAgentsClicked) promoBanner.classList.add("hidden");
      else promoBanner.classList.remove("hidden");

      const bannerTitle = promoBanner.querySelector("h4");
      if (bannerTitle) {
        if (rateUsClicked && !aiAgentsClicked)
          bannerTitle.textContent = "🤖 Check out our AI agents too!";
        else if (aiAgentsClicked && !rateUsClicked)
          bannerTitle.textContent = "⭐ Don't forget to rate us!";
        else if (!rateUsClicked && !aiAgentsClicked)
          bannerTitle.textContent = "✨ Help us improve & discover more!";
      }
    };

    updateStatus();

    if (rateUsLink) {
      rateUsLink.addEventListener("click", () => {
        localStorage.setItem("promoRateUsClicked", "true");
        if (window.Analytics?.trackRateUsClick)
          window.Analytics.trackRateUsClick("promo_banner");
        updateStatus();
      });
    }

    if (aiAgentsLink) {
      aiAgentsLink.addEventListener("click", () => {
        localStorage.setItem("promoAiAgentsClicked", "true");
        if (window.Analytics?.trackAIAgentHubClick)
          window.Analytics.trackAIAgentHubClick("promo_banner");
        updateStatus();
      });
    }

    if (promoClose) {
      promoClose.addEventListener("click", (e) => {
        e.preventDefault();
        promoBanner.classList.add("hidden");
        localStorage.setItem("promoBannerClosed", "true");
      });
    }
  },

  setupAdditionalToolsHandlers() {
    const toolsLinks = document.querySelectorAll(
      ".additional-tools .tool-link",
    );
    toolsLinks.forEach((link) => {
      link.addEventListener("click", () => {
        const text = link.textContent.trim().toLowerCase();
        if (text.includes("ai")) {
          if (window.Analytics?.trackAIAgentHubClick)
            window.Analytics.trackAIAgentHubClick("additional_tools");
        } else {
          if (window.Analytics?.trackMultiWebSpeedTestClick)
            window.Analytics.trackMultiWebSpeedTestClick("additional_tools");
        }
      });
    });
  },

  setupModalCloseHandlers() {
    const { state } = window.PopupApp;
    document.querySelectorAll(".modal .close").forEach((closeBtn) => {
      closeBtn.addEventListener("click", () => {
        if (closeBtn.closest("#load-test-modal")) {
          if (!state.isLoadTestRunning) {
            closeBtn.closest(".modal").style.display = "none";
          }
        } else {
          closeBtn.closest(".modal").style.display = "none";
        }
      });
    });
  },
};
